import java.text.SimpleDateFormat;
import java.util.*;

class Account {
    private int accountNumber;
    private String customerName;
    private double balance;
    private String accountType;
    private List<String> transactionHistory;
    private static final double TRANSACTION_FEE = 1.0; 
    private static final double SAVINGS_INTEREST_RATE = 0.04; 
    private double overdraftLimit;
    private Loan loan;
    private Card card;
    private String password;  

    public Account(int accountNumber, String customerName, double balance, String accountType, String password) {
        this.accountNumber = accountNumber;
        this.customerName = customerName;
        this.balance = balance;
        this.accountType = accountType;
        this.transactionHistory = new ArrayList<>();
        this.password = password;  
        addTransaction("Account created with balance: " + balance);
        if (accountType.equalsIgnoreCase("Current")) {
            this.overdraftLimit = 5000.0; 
        }
    }
    public void deposit(double amount) {
        balance += amount - TRANSACTION_FEE;  
        addTransaction("Deposited: " + amount + " (Fee: " + TRANSACTION_FEE + ")");
        System.out.println("Deposited: " + amount);
    }

    public void withdraw(double amount) {
        if (amount <= balance + overdraftLimit) {
            balance -= amount + TRANSACTION_FEE;
            addTransaction("Withdrawn: " + amount + " (Fee: " + TRANSACTION_FEE + ")");
            System.out.println("Withdrawn: " + amount);
        } else {
            System.out.println("Insufficient balance or overdraft limit.");
        }
    }

    public void checkBalance() {
        System.out.println("Balance: " + balance);
    }
    public boolean authenticate(String enteredPassword) {
        return this.password.equals(enteredPassword);  
    }

    public void showTransactionHistory() {
        System.out.println("Transaction History for Account Number: " + accountNumber);
        if (transactionHistory.isEmpty()) {
            System.out.println("No transactions yet.");
        } else {
            for (String transaction : transactionHistory) {
                System.out.println(transaction);
            }
        }
    }

    private void addTransaction(String transaction) {
        transactionHistory.add(transaction);
    }

    public void addInterest() {
        if (accountType.equalsIgnoreCase("Savings")) {
            double interest = balance * SAVINGS_INTEREST_RATE;
            balance += interest;
            addTransaction("Interest added: " + interest);
            System.out.println("Interest added: " + interest);
        }
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getAccountType() {
        return accountType;
    }

    // Transfer money to another account
    public void transferMoney(Account recipient, double amount) {
        if (amount <= this.balance + this.overdraftLimit) {
            this.balance -= amount + TRANSACTION_FEE;
            recipient.balance += amount;
            addTransaction("Transferred: " + amount + " to Account Number: " + recipient.getAccountNumber() + " (Fee: " + TRANSACTION_FEE + ")");
            recipient.addTransaction("Received: " + amount + " from Account Number: " + this.getAccountNumber());
            System.out.println("Transferred: " + amount + " to Account Number: " + recipient.getAccountNumber());
        } else {
            System.out.println("Insufficient balance or overdraft limit.");
        }
    }

    // Loan-related methods
    public void applyForLoan(String loanType, double loanAmount, Date dueDate) {
        loan = new Loan(loanType, loanAmount, dueDate);
        addTransaction("Loan applied: " + loanType + " for amount: " + loanAmount);
        System.out.println("Loan applied: " + loanType + " for amount: " + loanAmount);
    }

    public Loan getLoan() {
        return loan;
    }

    // Card-related methods
    public void requestCard() {
        card = new Card("CARD" + accountNumber, 5000); 
        addTransaction("Card requested.");
        System.out.println("Card requested.");
    }

    public void blockCard() {
        if (card != null) {
            card.block();
            addTransaction("Card blocked.");
        } else {
            System.out.println("No card found.");
        }
    }

    public void unfreezeCard() {
        if (card != null) {
            card.unfreeze();
            addTransaction("Card unfrozen.");
        } else {
            System.out.println("No card found.");
        }
    }

    public void updateCardLimit(double newLimit) {
        if (card != null) {
            card.updateLimit(newLimit);
            addTransaction("Card limit updated to: " + newLimit);
        } else {
            System.out.println("No card found.");
        }
    }

    
    public void requestBalanceCertificate() {
        addTransaction("Balance certificate requested.");
        System.out.println("Balance certificate requested.");
    }

    public void requestAccountClosure() {
        addTransaction("Account closure requested.");
        System.out.println("Account closure requested.");
    }

    public void raiseComplaint(String complaint) {
        addTransaction("Complaint raised: " + complaint);
        System.out.println("Complaint raised: " + complaint);
    }

    public List<String> getAlerts() {
        return transactionHistory;  
    }
}

class Loan {
    private String loanType;
    private double amount;
    private Date dueDate;
    private String status; 
    private double balance;

    public Loan(String loanType, double amount, Date dueDate) {
        this.loanType = loanType;
        this.amount = amount;
        this.dueDate = dueDate;
        this.status = "Pending";
        this.balance = amount;
    }

    public String getStatus() {
        return status;
    }

    public double getBalance() {
        return balance;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void makePayment(double paymentAmount) {
        balance -= paymentAmount;
        if (balance <= 0) {
            status = "Approved";
            System.out.println("Loan fully paid. Status: Approved");
        }
    }

    @Override
    public String toString() {
        return "Loan Type: " + loanType + ", Amount: " + amount + ", Due Date: " + dueDate + ", Status: " + status;
    }
}

class Card {
    private String cardNumber;
    private boolean blocked;
    private boolean frozen;
    private double limit;

    public Card(String cardNumber, double limit) {
        this.cardNumber = cardNumber;
        this.limit = limit;
        this.blocked = false;
        this.frozen = false;
    }

    public void block() {
        blocked = true;
        System.out.println("Card blocked.");
    }

    public void unfreeze() {
        frozen = false;
        System.out.println("Card unfrozen.");
    }

    public void updateLimit(double newLimit) {
        limit = newLimit;
        System.out.println("Card limit updated to: " + limit);
    }
}

public class BankSystemm {
    private static Map<Integer, Account> accounts = new HashMap<>();
    private static Scanner scanner = new Scanner(System.in);
    private static int currentAccountNumber = -1;
    private static final String ADMIN_USERNAME = "admin";
    private static final String ADMIN_PASSWORD = "admin123";

    public static void main(String[] args) {
        while (true) {
            if (currentAccountNumber == -1) {
                System.out.println("1. User Login");
                System.out.println("2. Admin Login");
                int loginChoice = scanner.nextInt();
                if (loginChoice == 1) {
                    authenticateUser();
                } else if (loginChoice == 2) {
                    authenticateAdmin();
                }
            } else {
                showUserMenu();
            }
        }
    }

    private static void authenticateUser() {
        System.out.println("Enter Account Number:");
        int accountNumber = scanner.nextInt();
        Account account = accounts.get(accountNumber);

        if (account != null) {
            System.out.println("Enter Password:");
            scanner.nextLine();  
            String password = scanner.nextLine();
            if (account.authenticate(password)) {  
                System.out.println("Welcome, " + account.getCustomerName());
                currentAccountNumber = accountNumber;
            } else {
                System.out.println("Incorrect password.");
            }
        } else {
            System.out.println("Invalid Account Number.");
        }
    }

    private static void showUserMenu() {
        Account account = accounts.get(currentAccountNumber);
        int choice;
        do {
            System.out.println("\nUser Menu:");
            System.out.println("1. Deposit\n2. Withdraw\n3. Check Balance\n4. View Transaction History\n5. Apply for Loan\n6. Loan Services\n7. Card Management\n8. Service Requests\n9. Notifications and Alerts\n10. Transfer Money\n11. Logout");
            choice = scanner.nextInt();
    
            switch (choice) {
                case 1:
                    System.out.println("Enter amount to deposit:");
                    double depositAmount = scanner.nextDouble();
                    account.deposit(depositAmount);
                    break;
                case 2:
                    System.out.println("Enter amount to withdraw:");
                    double withdrawAmount = scanner.nextDouble();
                    account.withdraw(withdrawAmount);
                    break;
                case 3:
                    account.checkBalance();
                    break;
                case 4:
                    account.showTransactionHistory();
                    break;
                case 5:
                    applyForLoan(account);
                    break;
                case 6:
                    loanServices(account);
                    break;
                case 7:
                    cardManagement(account);
                    break;
                case 8:
                    serviceRequests(account);
                    break;
                case 9:
                    checkAlerts(account);
                    break;
                case 10:
                    transferMoney(account); 
                    break;
                case 11:
                    currentAccountNumber = -1;
                    System.out.println("Logged out successfully.");
                    break;
                default:
                    System.out.println("Invalid choice.");
                    break;
            }
        } while (choice != 11);
    }
    
    private static void applyForLoan(Account account) {
        if (account.getLoan() == null) {
            System.out.println("Enter loan type (Personal, Home, Car):");
            String loanType = scanner.next();
            System.out.println("Enter loan amount:");
            double loanAmount = scanner.nextDouble();
            System.out.println("Enter due date (YYYY-MM-DD):");
            String dueDateStr = scanner.next();
            try {
                Date dueDate = new SimpleDateFormat("yyyy-MM-dd").parse(dueDateStr);
                account.applyForLoan(loanType, loanAmount, dueDate);
                System.out.println("Loan application submitted.");
            } catch (Exception e) {
                System.out.println("Invalid date format.");
            }
        } else {
            System.out.println("You already have an existing loan.");
        }
    }

    private static void loanServices(Account account) {
        Loan loan = account.getLoan();
        if (loan != null) {
            System.out.println("Loan Status: " + loan.getStatus());
            System.out.println("Loan Balance: " + loan.getBalance());
            System.out.println("Loan Due Date: " + loan.getDueDate());
        } else {
            System.out.println("No active loan.");
        }
    }

    private static void cardManagement(Account account) {
        System.out.println("1. Request Card\n2. Block Card\n3. Unfreeze Card\n4. Update Card Limit");
        int choice = scanner.nextInt();
        switch (choice) {
            case 1:
                account.requestCard();
                break;
            case 2:
                account.blockCard();
                break;
            case 3:
                account.unfreezeCard();
                break;
            case 4:
                System.out.println("Enter new card limit:");
                double newLimit = scanner.nextDouble();
                account.updateCardLimit(newLimit);
                break;
            default:
                System.out.println("Invalid choice.");
                break;
        }
    }

    private static void serviceRequests(Account account) {
        System.out.println("1. Request Balance Certificate\n2. Request Account Closure\n3. Raise Complaint");
        int choice = scanner.nextInt();
        switch (choice) {
            case 1:
                account.requestBalanceCertificate();
                break;
            case 2:
                account.requestAccountClosure();
                break;
            case 3:
                System.out.println("Enter your complaint:");
                scanner.nextLine();  
                String complaint = scanner.nextLine();
                account.raiseComplaint(complaint);
                break;
            default:
                System.out.println("Invalid choice.");
                break;
        }
    }

    private static void checkAlerts(Account account) {
        System.out.println("Alerts: ");
        List<String> alerts = account.getAlerts();
        if (alerts.isEmpty()) {
            System.out.println("No alerts.");
        } else {
            for (String alert : alerts) {
                System.out.println(alert);
            }
        }
    }
    private static void transferMoney(Account senderAccount) {
        System.out.println("Enter recipient's Account Number:");
        int recipientAccountNumber = scanner.nextInt();
        Account recipientAccount = accounts.get(recipientAccountNumber);
        
        if (recipientAccount != null && recipientAccountNumber != senderAccount.getAccountNumber()) {
            System.out.println("Enter amount to transfer:");
            double amount = scanner.nextDouble();
            
            if (amount > 0) {
                senderAccount.transferMoney(recipientAccount, amount);
            } else {
                System.out.println("Amount must be positive.");
            }
        } else {
            System.out.println("Invalid recipient account number or cannot transfer to the same account.");
        }
    }

    private static void authenticateAdmin() {
        System.out.println("Enter username:");
        String username = scanner.next();
        System.out.println("Enter password:");
        String password = scanner.next();

        if (ADMIN_USERNAME.equals(username) && ADMIN_PASSWORD.equals(password)) {
            System.out.println("Welcome, Admin");
            showAdminMenu();
        } else {
            System.out.println("Invalid credentials.");
        }
    }

    private static void showAdminMenu() {
        int choice;
        do {
            System.out.println("\nAdmin Menu:");
            System.out.println("1. Add New Account\n2. View All Accounts\n3. View Account Details\n4. Logout");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addNewAccount();
                    break;
                case 2:
                    viewAllAccounts();
                    break;
                case 3:
                    viewAccountDetails();
                    break;
                case 4:
                    currentAccountNumber = -1;
                    System.out.println("Logged out successfully.");
                    break;
                default:
                    System.out.println("Invalid choice.");
                    break;
            }
        } while (choice != 4);
    }

    private static void addNewAccount() {
        System.out.println("Enter Account Number:");
        int accountNumber = scanner.nextInt();
        scanner.nextLine();  
        System.out.println("Enter Customer Name:");
        String customerName = scanner.nextLine();
        System.out.println("Enter Initial Balance:");
        double balance = scanner.nextDouble();
        scanner.nextLine();  
        System.out.println("Enter Account Type (Savings/Current):");
        String accountType = scanner.nextLine();
        System.out.println("Enter Password for the account:");
        String password = scanner.nextLine();  
    
        
        Account newAccount = new Account(accountNumber, customerName, balance, accountType, password);
        accounts.put(accountNumber, newAccount);
        System.out.println("Account created successfully!");
    }
    
    private static void viewAllAccounts() {
        if (accounts.isEmpty()) {
            System.out.println("No accounts available.");
        } else {
            System.out.println("All Accounts:");
            for (Account account : accounts.values()) {
                System.out.println("Account Number: " + account.getAccountNumber() + ", Customer Name: " + account.getCustomerName() + ", Type: " + account.getAccountType());
            }
        }
    }

    private static void viewAccountDetails() {
        System.out.println("Enter Account Number:");
        int accountNumber = scanner.nextInt();
        Account account = accounts.get(accountNumber);

        if (account != null) {
            System.out.println("Account Number: " + account.getAccountNumber());
            System.out.println("Customer Name: " + account.getCustomerName());
            System.out.println("Account Type: " + account.getAccountType());
            System.out.println("Balance: " );
            account.checkBalance();
        } else {
            System.out.println("Account not found.");
        }
    }
}
